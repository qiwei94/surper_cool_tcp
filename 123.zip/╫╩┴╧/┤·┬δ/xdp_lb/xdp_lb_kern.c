/*
 * Copyright 2004-present Facebook. All Rights Reserved.
 * This is main balancer's application code
 */

#include <uapi/linux/bpf.h>
#include <uapi/linux/in.h>

#include <uapi/linux/if_ether.h>
#include <uapi/linux/if_packet.h>

#include <uapi/linux/ip.h>
#include <uapi/linux/ipv6.h>
#include <stddef.h>
#include <linux/bug.h>
#include <uapi/linux/pkt_cls.h>

#include <uapi/linux/tcp.h>
#include <uapi/linux/filter.h>
#include <linux/jhash.h>

#include "bpf_helpers.h"

#include "balancer_consts.h"
#include "balancer_structs.h"
#include "pckt_encap.h"
#include "pckt_parsing.h"
#include "handle_icmp.h"

#define _htonl __builtin_bswap32

// map which contains opaque real's id to real mapping
struct bpf_map_def SEC("maps") reals = {
  .type = BPF_MAP_TYPE_ARRAY,
  .key_size = sizeof(__u32),
  .value_size = sizeof(struct real_definition),
  .max_entries = MAX_REALS,
  .map_flags = NO_FLAGS,
  //.pinning = PIN_GLOBAL_NS,
};


// control array. contains metadata such as default router mac
// and/or interfaces ifindexes
// indexes:
// 0 - default's mac
struct bpf_map_def SEC("maps") ctl_array = {
  .type = BPF_MAP_TYPE_ARRAY,
  .key_size = sizeof(__u32),
  .value_size = sizeof(struct ctl_value),
  .max_entries = CTL_MAP_SIZE,
  .map_flags = NO_FLAGS,
  //.pinning = PIN_GLOBAL_NS,
};





__attribute__((__always_inline__))
static inline __u32 get_packet_hash(struct packet_description *pckt,
                                    bool hash_16bytes) {
  if (hash_16bytes) {
    return jhash_2words(jhash(pckt->flow.srcv6, 16, MAX_VIPS),
                        pckt->flow.ports, CH_RINGS_SIZE);
  } else {
    return jhash_2words(pckt->flow.src, pckt->flow.ports, CH_RINGS_SIZE);
  }
}



__attribute__((__always_inline__))
static inline int process_l3_headers(struct packet_description *pckt,
                                     __u8 *protocol, __u64 off,
                                     __u16 *pkt_bytes, void *data,
                                     void *data_end, bool is_ipv6) {
  __u64 iph_len;
  int action;
  struct iphdr *iph;
  struct ipv6hdr *ip6h;
  if (is_ipv6) {
    ip6h = data + off;
    if (ip6h + 1 > data_end) {
      return XDP_DROP;
    }

    iph_len = sizeof(struct ipv6hdr);
    *protocol = ip6h->nexthdr;
    pckt->flow.proto = *protocol;
    *pkt_bytes = ntohs(ip6h->payload_len);
    off += iph_len;
    if (*protocol == IPPROTO_FRAGMENT) {
      // we drop fragmented packets
      return XDP_DROP;
    } else if (*protocol == IPPROTO_ICMPV6) {
      action = parse_icmpv6(data, data_end, off, pckt);
      if (action >= 0) {
        return action;
      }
    } else {
      memcpy(pckt->flow.srcv6, ip6h->saddr.s6_addr32, 16);
      memcpy(pckt->flow.dstv6, ip6h->daddr.s6_addr32, 16);
    }
  } else {
    iph = data + off;
    if (iph + 1 > data_end) {
      return XDP_DROP;
    }
    //ihl contains len of ipv4 header in 32bit words
    if (iph->ihl != 5) {
      // if len of ipv4 hdr is not equal to 20bytes that means that header
      // contains ip options, and we dont support em
      return XDP_DROP;
    }

    *protocol = iph->protocol;
    pckt->flow.proto = *protocol;
    *pkt_bytes = ntohs(iph->tot_len);
    off += IPV4_HDR_LEN_NO_OPT;

    if (iph->frag_off & PCKT_FRAGMENTED) {
      // we drop fragmented packets.
      return XDP_DROP;
    }
    if (*protocol == IPPROTO_ICMP) {
      char fmt5[] = "fuck icmp \n";
      //bpf_trace_printk(fmt5, sizeof(fmt5));
      action = parse_icmp(data, data_end, off, pckt);
      if (action >= 0) {
        return action;
      }
    } else {
      pckt->flow.src = iph->saddr;
      pckt->flow.dst = iph->daddr;

      __be32 daddr = iph->daddr;
      char fmt4[] = "packet daddr4 : %x\n";
      //bpf_trace_printk(fmt4, sizeof(fmt4), _htonl(daddr));
      //bpf_trace_printk(fmt4, sizeof(fmt4), (daddr));


    }
  }
  return FURTHER_PROCESSING;
}

__attribute__((__always_inline__))
static inline int process_encaped_pckt(void **data, void **data_end,
                                       struct xdp_md *xdp, bool *is_ipv6,
                                       struct packet_description *pckt,
                                       __u8 *protocol, __u64 off,
                                       __u16 *pkt_bytes) {
  int action;
  if (*protocol == IPPROTO_IPIP) {
    if (*is_ipv6) {
      if ((*data + sizeof(struct ipv6hdr) +
           sizeof(struct eth_hdr)) > *data_end) {
        return XDP_DROP;
      }
      if (!decap_v6(xdp, data, data_end, true)) {
        return XDP_DROP;
      }
      *is_ipv6 = false;
    } else {
      if ((*data + sizeof(struct iphdr) +
           sizeof(struct eth_hdr)) > *data_end) {
        return XDP_DROP;
      }
      if (!decap_v4(xdp, data, data_end)) {
        return XDP_DROP;
      }
    }
    off = sizeof(struct eth_hdr);
    if (*data + off > *data_end) {
      return XDP_DROP;
    }
    action = process_l3_headers(
      pckt, protocol, off, pkt_bytes, *data, *data_end, false);
    if (action >= 0) {
      return action;
    }
    *protocol = pckt->flow.proto;
  } else if (*protocol == IPPROTO_IPV6) {
    if ((*data + sizeof(struct ipv6hdr) +
         sizeof(struct eth_hdr)) > *data_end) {
      return XDP_DROP;
    }
    if (!decap_v6(xdp, data, data_end, false)) {
      return XDP_DROP;
    }
    off = sizeof(struct eth_hdr);
    if (*data + off > *data_end) {
      return XDP_DROP;
    }
    action = process_l3_headers(
      pckt, protocol, off, pkt_bytes, *data, *data_end, true);
    if (action >= 0) {
      return action;
    }
    *protocol = pckt->flow.proto;
  }
  return FURTHER_PROCESSING;
}




__attribute__((__always_inline__)) 
static inline bool encap_v4_simple(struct xdp_md *xdp,
                                   struct packet_description *pckt, 
                                   __u32 pkt_bytes) {
  void *data;
  void *data_end;
  struct iphdr *iph;
  struct eth_hdr *new_eth;
  struct eth_hdr *old_eth;
  __u32 ip_suffix = htons(pckt->flow.port16[0]);

  __u32 ip_suffix_back = htons(pckt->flow.port16[0]);

  ip_suffix <<= 16;
  ip_suffix ^= pckt->flow.src;
  __u16 *next_iph_u16;
  __u32 csum = 0;
  // ipip encap
  if (bpf_xdp_adjust_head(xdp, 0 - (int)sizeof(struct iphdr))) {
    return false;
  }
  data = (void *)(long)xdp->data;
  data_end = (void *)(long)xdp->data_end;
  new_eth = data;
  iph = data + sizeof(struct eth_hdr);
  old_eth = data + sizeof(struct iphdr);
  if (new_eth + 1 > data_end ||
      old_eth + 1 > data_end ||
      iph + 1 > data_end) {
    return false;
  }
  
  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////
    //00:0c:29:84:85:df
    //0
    //12
    //41
    //132
    //133
    //223
    
    //90:e2:ba:24:d1:30
    //144
    //226
    //186
    //36
    //209
    //48
    unsigned char mac_dst[ETH_ALEN];
    mac_dst[0]=144;
    mac_dst[1]=226;
    mac_dst[2]=186;
    mac_dst[3]=36;
    mac_dst[4]=209;
    mac_dst[5]=48;

  memcpy(new_eth->eth_dest, mac_dst, 6);
  //memcpy(new_eth->eth_dest, cval->mac, 6);

  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////


  memcpy(new_eth->eth_source, old_eth->eth_dest, 6);
  new_eth->eth_proto = BE_ETH_P_IP;

  iph->version = 4;
  iph->ihl = 5;
  iph->frag_off = 0;
  iph->protocol = IPPROTO_IPIP;
  iph->check = 0;
  // as w/ v6 we could configure tos to something else
  iph->tos = 0;
  iph->tot_len = htons(pkt_bytes + sizeof(struct iphdr));
  


  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////
 
  __be32 const_rip = 0x0a000202;
  __be32 const_rip_host = 0x0302000a;

  iph->daddr = const_rip_host;
  //iph->daddr = dst->dst;
  
  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////



  //iph->saddr = ((0xFFFF0000 & ip_suffix) | IPIP_V4_PREFIX);
  __be32 const_ipip_src = 0x01010a0a;
  iph->saddr = const_ipip_src;

  ///////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////

  
  iph->ttl = DEFAULT_TTL;

  next_iph_u16 = (__u16 *)iph;

  #pragma clang loop unroll(full)
  for (int i = 0; i < sizeof(struct iphdr) >> 1; i++) {
     csum += *next_iph_u16++;
  }
  iph->check = ~((csum & 0xffff) + (csum >> 16));


  char fmt10[] = "i do , go to check the packet \n";
  //bpf_trace_printk(fmt10,sizeof(fmt10));

  return true;
}



__attribute__((__always_inline__))
static inline int process_packet(void *data, __u64 off, void *data_end,
                                 bool is_ipv6, struct xdp_md *xdp) {

  struct ctl_value *cval;
  struct real_definition *dst = NULL;
  struct packet_description pckt = {};
  struct vip_definition vip = {};
  struct vip_meta *vip_info;
  struct lb_stats *data_stats;
  __u64 iph_len;
  __u8 protocol;

  int action;
  __u32 vip_num;
  __u32 mac_addr_pos = 0;
  __u16 pkt_bytes;
  action = process_l3_headers(
    &pckt, &protocol, off, &pkt_bytes, data, data_end, is_ipv6);
  if (action >= 0) {
    return action;
  }
  protocol = pckt.flow.proto;

  // prototype for inline decapsulation / could be used for
  // microbenchmarks with katran_tester
  // action = process_encaped_pckt(&data, &data_end, xdp, &is_ipv6, &pckt,
  //                               &protocol, off, &pkt_bytes);
  // if (action >= 0) {
  //   return action;
  // }

  if (protocol == IPPROTO_TCP) {
    if (!parse_tcp(data, data_end, is_ipv6, &pckt)) {
      return XDP_DROP;
    }
  } else if (protocol == IPPROTO_UDP) {
    if (!parse_udp(data, data_end, is_ipv6, &pckt)) {
      return XDP_DROP;
    }
  } else {
    // send to tcp/ip stack
    return XDP_PASS;
  }

  
  vip.vip = pckt.flow.dst;
  vip.port = pckt.flow.port16[1];
  vip.proto = pckt.flow.proto;
  
  __be32 daddr = pckt.flow.dst;
  __be32 const_vip = 0x0a00060a;
  __be32 const_rip = 0x0a000202;
  __be32 const_rip_host = 0x0202000a;

  if(_htonl(daddr) == const_vip){


    void *data;
    void *data_end;
    data = (void *)(long)xdp->data;
    data_end = (void *)(long)xdp->data_end;
    
    struct eth_hdr *eth;
    __u64 off2 = sizeof(struct eth_hdr);
    if(data + sizeof(*eth) > data_end){
      return XDP_DROP;
    }
    
    eth=data;

    // 00:0c:29:84:85:df 
    //unsigned char mac_source[ETH_ALEN];
    //mac_source[0]=eth->eth_source[0];
    //mac_source[1]=eth->eth_source[1];
    //mac_source[2]=eth->eth_source[2];
    //mac_source[3]=eth->eth_source[3];
    //mac_source[4]=eth->eth_source[4];
    //mac_source[5]=eth->eth_source[5];
    //char fmt7[] = "mac is %u \n";
    //bpf_trace_printk(fmt7, sizeof(fmt7),mac_source[0]);
    //bpf_trace_printk(fmt7, sizeof(fmt7),mac_source[1]);
    //bpf_trace_printk(fmt7, sizeof(fmt7),mac_source[2]);
    //bpf_trace_printk(fmt7, sizeof(fmt7),mac_source[3]);
    //bpf_trace_printk(fmt7, sizeof(fmt7),mac_source[4]);
    //bpf_trace_printk(fmt7, sizeof(fmt7),mac_source[5]);
    
    //cval = bpf_map_lookup_elem(&ctl_array, &mac_addr_pos);
    //__u32 key = 0;
    //dst = bpf_map_lookup_elem(&reals, &key);
    //if(!dst){
    //  char fmt10[] = "no find dst\n";
    //  bpf_trace_printk(fmt10,sizeof(fmt10));
    //  return XDP_PASS;
    //}else{
    //   __be32 daddr = dst->dst;
    //  char fmt40[] = "packet daddr4 : %x\n";
    //  //bpf_trace_printk(fmt4, sizeof(fmt4), _htonl(daddr));
    //  bpf_trace_printk(fmt40, sizeof(fmt40), (daddr));
    //}

    //cval->mac[0]=mac_dst[0];
    //cval->mac[1]=mac_dst[1];
    //cval->mac[2]=mac_dst[2];
    //cval->mac[3]=mac_dst[3];
    //cval->mac[4]=mac_dst[4];
    //cval->mac[5]=mac_dst[5];
    //memcpy(cval->mac, mac_dst ,6);
    //memcpy(&(dst->dst),&const_rip_host,sizeof(__be32));
    //dst->dst=const_rip_host;

    if(!encap_v4_simple(xdp, &pckt, pkt_bytes)) {
        return XDP_DROP;
      }

  }else{
    char fmt8[] = "it is not what we want \n";
    //bpf_trace_printk(fmt8, sizeof(fmt8));
    return XDP_PASS;
  }

  //if(!encap_v4(xdp, cval, &pckt, dst, pkt_bytes)) {
  //    return XDP_DROP;
  //}
  
 
  return XDP_TX;
}


SEC("xdp-balancer")
int balancer_ingress(struct xdp_md *ctx) {
  void *data = (void *)(long)ctx->data;
  void *data_end = (void *)(long)ctx->data_end;
  struct eth_hdr *eth = data;
  __u32 eth_proto;
  __u32 nh_off;
  nh_off = sizeof(struct eth_hdr);

  char fmt5[] = "fuck in it \n";

  //bpf_trace_printk(fmt5, sizeof(fmt5));

  if (data + nh_off > data_end) {
    // bogus packet, len less than minimum ethernet frame size
    char fmt4[] = "fuck here??? \n";
    //bpf_trace_printk(fmt4, sizeof(fmt4));
    return XDP_DROP;
  }
  char fmt6[] = "do it \n";

  eth_proto = eth->eth_proto;

  if (eth_proto == BE_ETH_P_IP) {
    //bpf_trace_printk(fmt6, sizeof(fmt6));
    return process_packet(data, nh_off, data_end, false, ctx);
    //bpf_trace_printk(fmt6, sizeof(fmt6));
  } else {
    // pass to tcp/ip stack
    return XDP_PASS;
  }
}



char _license[] SEC("license") = "GPL";
