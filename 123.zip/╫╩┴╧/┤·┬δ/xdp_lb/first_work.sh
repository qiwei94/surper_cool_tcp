subl #!/bin/bash
# SPDX-License-Identifier: GPL-2.0

[[ -z $TC ]] && TC='tc'
[[ -z $IP ]] && IP='ip'

REDIRECT_USER='./xdp_lb'
REDIRECT_BPF='./xdp_lb_kern.o'

RP_FILTER=$(< /proc/sys/net/ipv4/conf/all/rp_filter)
IPV6_FORWARDING=$(< /proc/sys/net/ipv6/conf/all/forwarding)

function config_common {
	local tun_type=$1

	sysctl -q -w net.ipv4.conf.all.rp_filter=0
	sysctl -q -w net.ipv6.conf.all.forwarding=1
}

function cleanup {
	set +e
	[[ -z $DEBUG ]] || set +x
	#$IP netns delete ns1 >& /dev/null
	#$IP netns delete ns2 >& /dev/null
	#$IP link del ve1 >& /dev/null
	#$IP link del ve2 >& /dev/null
	#$IP link del ipt >& /dev/null
	#$IP link del ip6t >& /dev/null
	#pkill cat
	sysctl -q -w net.ipv4.conf.all.rp_filter=$RP_FILTER
	sysctl -q -w net.ipv6.conf.all.forwarding=$IPV6_FORWARDING
	rm -f /sys/fs/bpf/tc/globals/tun_iface
	[[ -z $DEBUG ]] || set -x
	set -e
}

function l2_to_ipip {
	
	config_common
	

	#$IP qdisc del dev enp6s0f0 clsact
	#$IP qdisc add dev enp6s0f0 clsact
	
	
	$IP -force link set dev enp6s0f0 xdp obj $REDIRECT_BPF sec xdp-balancer
	
	#cat /sys/kernel/debug/tracing/trace_pipe &

	#$REDIRECT_USER -U /sys/fs/bpf/tc/globals/tun_iface -i $(< /sys/class/net/IXT/ifindex)

	read -p "Press enter to continue"
	
	$IP link set dev enp6s0f0 xdp off 

	cleanup

	echo "OK"
}



echo "cleanup"
cleanup
echo "begin run"
l2_to_ipip
