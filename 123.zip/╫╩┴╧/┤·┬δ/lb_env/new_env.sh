#!/bin/bash -x
. ./env_virable.sh

ip route del 10.0.3.0/24 via $request_path
ip route del 10.0.2.0/24 via $data_path
echo "clear all........................................"

# add the client and the target2 \ target3
echo 1 > /proc/sys/net/ipv4/ip_forward
echo "enable ipv4 forwarding ........................................"

ip route add 10.0.3.0/24 via $request_path
ip route add 10.0.2.0/24 via $data_path


echo "add basic 2.0 and 3.0 routing  ........................................"


echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter

echo "echo 0 > rp_filter........................................"

#echo 2 > /proc/sys/net/ipv4/conf/br0/rp_filter

#tc_l2_redirect -U /sys/fs/bpf/tc/globals/tun_iface -i $(< /sys/class/net/ens38/ifindex)


tc qdisc add dev $local_request_dev clsact

echo "tc qdisc add dev ens38 clsact ........................................"








