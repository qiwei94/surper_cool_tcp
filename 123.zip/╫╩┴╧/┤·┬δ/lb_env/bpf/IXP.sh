#!/bin/bash -x
.  ./../env_virable.sh

#ip route del 10.0.6.0/24 dev IXT

ip -all tunnel delete IXT
modprobe ipip
#
#ip tunnel add IXT mode ipip remote $target2_addr local $local_data_path

ip link add IXT type ipip external
ip link set IXT up


ip addr add $bpf_tunnel_addr dev IXT

echo 0 > /proc/sys/net/ipv4/conf/IXT/rp_filter
##################################################################################################################need to change
#ip route add 10.0.6.0/24 dev IXT



