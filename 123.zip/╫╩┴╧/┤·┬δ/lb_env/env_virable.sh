#!/bin/bash -x

client_addr="10.0.3.2"
target2_addr="10.0.2.2"
target3_addr="10.0.2.3"

lvs_vip="10.0.4.1"
lvs_port="8010"

bpf_vip="10.0.6.10"
bpf_port="5001"
bpf_tunnel_addr="10.0.5.10"

request_path="10.10.1.2"
data_path="10.10.1.2"


local_request_path="10.10.1.1"
local_data_path="10.10.1.1"
local_request_dev="enp6s0f0"
local_data_dev="enp6s0f0"


