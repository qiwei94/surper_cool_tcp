#!/bin/bash
. ./../env_virable.sh


protocal='u'

echo "第一个参数为：$1"
echo "total 参数为：$#"

vir_num=$#
if [ -n "$1" ]
then
	mode=$1
	echo "mode is $mode"
else 
	mode="udp"
	echo "no point, use udp mode " 
fi


tcp="tcp"
udp="udp"


#if [ $tcp = $udp ]
#then
#   echo "$tcp = $udp : a 等于 b"
#else
#   echo "$tcp = $udp: a 不等于 b"
#fi


if [ $mode = $tcp ];
then
	protocal='t'
	echo "use tcp mode" 
elif [ $mode = $udp ];
then
	protocal='u'
	echo "use udp mode" 
else
	echo "unkown, use udp mode " 
fi


modprobe ip_vs
ipvsadm -C
ipvsadm -A -$protocal $lvs_vip:$lvs_port -s rr
ipvsadm -a -$protocal $lvs_vip:$lvs_port -r $target2_addr -i
ipvsadm -a -$protocal $lvs_vip:$lvs_port -r $target3_addr -i
ipvsadm -Ln


#echo "0" > /proc/sys/net/ipv4/ip_forward
echo "1" > /proc/sys/net/ipv4/conf/all/send_redirects
echo "1" > /proc/sys/net/ipv4/conf/default/send_redirects
echo "1" > /proc/sys/net/ipv4/conf/all/send_redirects







#echo 1 > /proc/sys/net/ipv4/conf/tunl0/arp_ignore
#echo 2 > /proc/sys/net/ipv4/conf/tunl0/arp_announce
#echo 1 > /proc/sys/net/ipv4/conf/all/arp_ignore
#echo 2 > /proc/sys/net/ipv4/conf/all/arp_announce
#echo 0 > /proc/sys/net/ipv4/conf/tunl0/rp_filter
#echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter