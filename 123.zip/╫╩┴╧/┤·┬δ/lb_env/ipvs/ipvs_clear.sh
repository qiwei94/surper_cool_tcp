#!/bin/bash -x
. ./../env_virable.sh

ip -all tunnel delete tun0

echo "clear $lvs_vip tunnel ........................................"

modprobe ip_vs
ipvsadm -C

echo "clear the whole ipvs table  ........................................"