#!/bin/bash -x
.  ./../env_virable.sh
##########################################################################################
######################   used for lvs basic 10.0.4.1   ###################################
##########################################################################################
#modprobe ipip
#


ip tunnel add tun0 mode ipip local $local_data_path dev $local_data_dev
#ip tunnel add tun0 mode ipip 
ip link set tun0 up
ip addr add $lvs_vip dev tun0

echo "add tunnel $local_data_path dev $local_data_dev ........................................"

