/* Copyright (c) 2016 Facebook
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 */
#define KBUILD_MODNAME "foo"
#include <uapi/linux/bpf.h>
#include <uapi/linux/if_ether.h>
#include <uapi/linux/if_packet.h>
#include <uapi/linux/ip.h>
#include <uapi/linux/ipv6.h>
#include <uapi/linux/in.h>
#include <uapi/linux/tcp.h>
#include <uapi/linux/filter.h>
#include <uapi/linux/pkt_cls.h>
#include <net/ipv6.h>
#include "bpf_helpers.h"

#define _htonl __builtin_bswap32

#define PIN_GLOBAL_NS		2
struct bpf_elf_map {
	__u32 type;
	__u32 size_key;
	__u32 size_value;
	__u32 max_elem;
	__u32 flags;
	__u32 id;
	__u32 pinning;
};

/* copy of 'struct ethhdr' without __packed */
struct eth_hdr {
	unsigned char   h_dest[ETH_ALEN];
	unsigned char   h_source[ETH_ALEN];
	unsigned short  h_proto;
};

struct bpf_elf_map SEC("maps") tun_iface = {
	.type = BPF_MAP_TYPE_ARRAY,
	.size_key = sizeof(int),
	.size_value = sizeof(int),
	.pinning = PIN_GLOBAL_NS,
	.max_elem = 1,
};

static __always_inline bool is_vip_addr(__be16 eth_proto, __be32 daddr)
{
	if (eth_proto == htons(ETH_P_IP))
		return (_htonl(0xffffffff) & daddr) == _htonl(0x0a00060a);//the vip is 10.0.6.10
	return false;
}



SEC("l2_to_iptun_ingress_redirect")
int _l2_to_iptun_ingress_redirect(struct __sk_buff *skb)
{
	struct bpf_tunnel_key tkey = {};
	struct bpf_tunnel_key raw_tkey = {};
	void *data = (void *)(long)skb->data;
	struct eth_hdr *eth = data;
	void *data_end = (void *)(long)skb->data_end;
	int key = 0, *ifindex;

	int ret;

	//char fmt5[] = "fuck in it \n";
	//bpf_trace_printk(fmt5, sizeof(fmt5));

	if (data + sizeof(*eth) > data_end){
		return TC_ACT_OK;
	}

	ifindex = bpf_map_lookup_elem(&tun_iface, &key);

	char fmt11[] = "died?? \n";
	//bpf_trace_printk(fmt11, sizeof(fmt11));

	if (!ifindex){
		char fmt50[] = "fuck in it,but not ifindex\n";
		//bpf_trace_printk(fmt50, sizeof(fmt50));
		return TC_ACT_OK;
	}

	if (eth->h_proto == htons(ETH_P_IP)) {
		char fmt4[] = "e/ingress redirect  saddr4:%x,daddr4:%x to ifindex:%d\n";
		struct iphdr *iph = data + sizeof(*eth);
		__be32 daddr = iph->daddr;
		__be32 saddr = iph->saddr;

		if (data + sizeof(*eth) + sizeof(*iph) > data_end)
			return TC_ACT_OK;

		//bpf_trace_printk(fmt4, sizeof(fmt4), _htonl(saddr),_htonl(daddr), *ifindex);
		if (!is_vip_addr(eth->h_proto, iph->daddr))
			return TC_ACT_OK;
	} else {
		char fmt12[] = "died??333 \n";
		//bpf_trace_printk(fmt12, sizeof(fmt12));
		return TC_ACT_OK;
	}


	tkey.tunnel_id = 10000;
	tkey.tunnel_ttl = 15;
	
	//tkey.remote_ipv4 = 0x0a000202; /* 10.0.2.2 */
	tkey.remote_ipv4 = 0x0a000203; /* 10.0.2.2 */
	
	ret = bpf_skb_set_tunnel_key(skb, &tkey, sizeof(tkey), 0);
	/*
	if(ret == 0){
		char fmt5[] = "success add key r_ip 0x%x\n";
		bpf_trace_printk(fmt5, sizeof(fmt5),tkey.remote_ipv4);
		//ret = bpf_skb_get_tunnel_key(skb,&raw_tkey,sizeof(raw_tkey),0);
		if(ret == 0){
			char fmt1[] = "get ip tun suc,tid:%d,ttl:%d,r_ip:0x%x\n";
			bpf_trace_printk(fmt1, sizeof(fmt1),raw_tkey.tunnel_id,raw_tkey.tunnel_ttl,raw_tkey.remote_ipv4);
			
			void *data = (void *)(long)skb->data;
			struct eth_hdr *eth = data;
			void *data_end = (void *)(long)skb->data_end;
			struct iphdr *iph = data + sizeof(*eth);
			__be32 daddr = iph->daddr;
			__be32 saddr = iph->saddr;

			if (data + sizeof(*eth) + sizeof(*iph) > data_end)
				return TC_ACT_OK;

			char fmt2[] = "now skb sip:%x,dip:%x\n";
			//bpf_trace_printk(fmt2, sizeof(fmt2), _htonl(saddr),_htonl(daddr));
			
		}
	}else{
		char fmt6[] = "add ip tun fail";
		bpf_trace_printk(fmt6, sizeof(fmt6));
	}
	*/

	//char fmt5[] = "fuck in it \n";
	//bpf_trace_printk(fmt5, sizeof(fmt5));

	if(ret == 0){
		return bpf_redirect(*ifindex, 0);
	}else{
		return TC_ACT_OK;
	}

	return TC_ACT_OK;
}


SEC("l2_to_iptun_ingress_forward")
int _l2_to_iptun_ingress_forward(struct __sk_buff *skb)
{
	struct bpf_tunnel_key tkey = {};
	struct bpf_tunnel_key raw_tkey = {};
	void *data = (void *)(long)skb->data;
	struct eth_hdr *eth = data;
	void *data_end = (void *)(long)skb->data_end;
	int key = 0, *ifindex;

	int ret;
	char fmt40[] = "in ve2 ingress , but no after ,why??";
	
	bpf_trace_printk(fmt40, sizeof(fmt40));
	
	if (data + sizeof(*eth) > data_end)
		return TC_ACT_OK;

	ifindex = bpf_map_lookup_elem(&tun_iface, &key);
	if (!ifindex)
		return TC_ACT_OK;

	if (eth->h_proto == htons(ETH_P_IP)) {
		char fmt4[] = "ingress forward to ifindex:%d daddr4:%x\n";
		struct iphdr *iph = data + sizeof(*eth);

		if (data + sizeof(*eth) + sizeof(*iph) > data_end)
			return TC_ACT_OK;

		if (iph->protocol != IPPROTO_IPIP)
			return TC_ACT_OK;
		else{
			char fmt1[] = "yes it is ipip packet,sip:%x,dip:%x\n";
			__be32 daddr = iph->daddr;
			__be32 saddr = iph->saddr;

			bpf_trace_printk(fmt1, sizeof(fmt1),_htonl(saddr),_htonl(daddr));


			ret = bpf_skb_get_tunnel_key(skb,&raw_tkey,sizeof(raw_tkey),0);
			if(ret == 0){
				char fmt1[] = "get ip tun suc,tid:%d,ttl:%d,r_ip:0x%x\n";
				bpf_trace_printk(fmt1, sizeof(fmt1),raw_tkey.tunnel_id,raw_tkey.tunnel_ttl,raw_tkey.remote_ipv4);
				
				void *data = (void *)(long)skb->data;
				struct eth_hdr *eth = data;
				void *data_end = (void *)(long)skb->data_end;
				struct iphdr *iph = data + sizeof(*eth);
				__be32 daddr = iph->daddr;
				__be32 saddr = iph->saddr;
	
				if (data + sizeof(*eth) + sizeof(*iph) > data_end)
					return TC_ACT_OK;
	
				char fmt2[] = "now skb sip:%x,dip:%x\n";
				bpf_trace_printk(fmt2, sizeof(fmt2), _htonl(saddr),_htonl(daddr));
				
			}else{
				char fmt6[] = "in ingress forward get ip tun fail\n";
				bpf_trace_printk(fmt6, sizeof(fmt6));
			}

		}

		bpf_trace_printk(fmt4, sizeof(fmt4), *ifindex,
				 _htonl(iph->daddr));
		return bpf_redirect(*ifindex, BPF_F_INGRESS);
	} else if (eth->h_proto == htons(ETH_P_IPV6)) {
		char fmt6[] = "ingress forward to ifindex:%d daddr6:%x::%x\n";
		struct ipv6hdr *ip6h = data + sizeof(*eth);

		if (data + sizeof(*eth) + sizeof(*ip6h) > data_end)
			return TC_ACT_OK;

		if (ip6h->nexthdr != IPPROTO_IPIP &&
		    ip6h->nexthdr != IPPROTO_IPV6)
			return TC_ACT_OK;

		bpf_trace_printk(fmt6, sizeof(fmt6), *ifindex,
				 _htonl(ip6h->daddr.s6_addr32[0]),
				 _htonl(ip6h->daddr.s6_addr32[3]));
		return bpf_redirect(*ifindex, BPF_F_INGRESS);
	}

	return TC_ACT_OK;
}



SEC("drop_non_tun_vip")
int _drop_non_tun_vip(struct __sk_buff *skb)
{
	struct bpf_tunnel_key tkey = {};
	void *data = (void *)(long)skb->data;
	struct eth_hdr *eth = data;
	void *data_end = (void *)(long)skb->data_end;

	if (data + sizeof(*eth) > data_end)
		return TC_ACT_OK;

	if (eth->h_proto == htons(ETH_P_IP)) {
		struct iphdr *iph = data + sizeof(*eth);

		if (data + sizeof(*eth) + sizeof(*iph) > data_end)
			return TC_ACT_OK;

		if (is_vip_addr(eth->h_proto, iph->daddr))
			return TC_ACT_SHOT;
	} else if (eth->h_proto == htons(ETH_P_IPV6)) {
		struct ipv6hdr *ip6h = data + sizeof(*eth);

		if (data + sizeof(*eth) + sizeof(*ip6h) > data_end)
			return TC_ACT_OK;

		if (is_vip_addr(eth->h_proto, ip6h->daddr.s6_addr32[0]))
			return TC_ACT_SHOT;
	}

	return TC_ACT_OK;
}

SEC("get_from_ipt_gress")
int _get_from_ipt_gress(struct __sk_buff *skb)
{
	struct bpf_tunnel_key tkey = {};
	struct bpf_tunnel_key raw_tkey = {};
	void *data = (void *)(long)skb->data;
	struct eth_hdr *eth = data;
	void *data_end = (void *)(long)skb->data_end;
	int key = 0;

	int ret;

	if (data + sizeof(*eth) > data_end)
		return TC_ACT_OK;

	if (eth->h_proto == htons(ETH_P_IP)) {
		char fmt4[] = "engress ipt daddr4:%x \n";
		struct iphdr *iph = data + sizeof(*eth);
		__be32 daddr = iph->daddr;

		if (data + sizeof(*eth) + sizeof(*iph) > data_end)
			return TC_ACT_OK;


		bpf_trace_printk(fmt4, sizeof(fmt4), _htonl(daddr));
	} else {
		return TC_ACT_OK;
	}


	struct iphdr *iph = data + sizeof(*eth);

	if (iph->protocol != IPPROTO_IPIP)
			return TC_ACT_OK;
	else{
		char fmt1[] = "ve1 it is ipip packet,sip:%x,dip:%x\n";
		void *data = (void *)(long)skb->data;
		struct eth_hdr *eth = data;
		void *data_end = (void *)(long)skb->data_end;
		struct iphdr *iph = data + sizeof(*eth);
		__be32 daddr = iph->daddr;
		__be32 saddr = iph->saddr;
		bpf_trace_printk(fmt1, sizeof(fmt1),_htonl(saddr),_htonl(daddr));
	}

	ret = bpf_skb_get_tunnel_key(skb,&raw_tkey,sizeof(raw_tkey),0);
	if(ret == 0){
		char fmt1[] = "ipt egress :get ip tun suc,tid:%d,ttl:%d,r_ip:0x%x\n";
		bpf_trace_printk(fmt1, sizeof(fmt1),raw_tkey.tunnel_id,raw_tkey.tunnel_ttl,raw_tkey.remote_ipv4);
		
		void *data = (void *)(long)skb->data;
		struct eth_hdr *eth = data;
		void *data_end = (void *)(long)skb->data_end;
		struct iphdr *iph = data + sizeof(*eth);
		__be32 daddr = iph->daddr;
		if (data + sizeof(*eth) + sizeof(*iph) > data_end)
			return TC_ACT_OK;
		char fmt2[] = "ipt egress now skb dip:%x\n";
		bpf_trace_printk(fmt2, sizeof(fmt2), _htonl(daddr));
		
	}else{
		char fmt1[] = "get ipip key fail";
		bpf_trace_printk(fmt1, sizeof(fmt1));
		
	}

}




char _license[] SEC("license") = "GPL";
