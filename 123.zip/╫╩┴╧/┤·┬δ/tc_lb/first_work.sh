#!/bin/bash
# SPDX-License-Identifier: GPL-2.0

[[ -z $TC ]] && TC='tc'
[[ -z $IP ]] && IP='ip'

DEV_NAME='enp6s0f0'

REDIRECT_USER='./tc_l2_redirect'
REDIRECT_BPF='./tc_l2_redirect_kern.o'

RP_FILTER=$(< /proc/sys/net/ipv4/conf/all/rp_filter)
IPV6_FORWARDING=$(< /proc/sys/net/ipv6/conf/all/forwarding)

function config_common {
	local tun_type=$1

	sysctl -q -w net.ipv4.conf.all.rp_filter=0
	sysctl -q -w net.ipv6.conf.all.forwarding=1
}

function cleanup {
	set +e
	[[ -z $DEBUG ]] || set +x
	#$IP netns delete ns1 >& /dev/null
	#$IP netns delete ns2 >& /dev/null
	#$IP link del ve1 >& /dev/null
	#$IP link del ve2 >& /dev/null
	#$IP link del ipt >& /dev/null
	#$IP link del ip6t >& /dev/null
	#pkill cat
	sysctl -q -w net.ipv4.conf.all.rp_filter=$RP_FILTER
	sysctl -q -w net.ipv6.conf.all.forwarding=$IPV6_FORWARDING
	rm -f /sys/fs/bpf/tc/globals/tun_iface
	[[ -z $DEBUG ]] || set -x
	set -e
}

function l2_to_ipip {
	
	config_common
	

	$TC qdisc del dev $DEV_NAME clsact
	$TC qdisc add dev $DEV_NAME clsact
	
	
	$TC filter add dev $DEV_NAME ingress bpf da obj $REDIRECT_BPF sec l2_to_iptun_ingress_redirect
	
	#cat /sys/kernel/debug/tracing/trace_pipe &

	$REDIRECT_USER -U /sys/fs/bpf/tc/globals/tun_iface -i $(< /sys/class/net/IXT/ifindex)

	read -p "Press enter to continue"
	
	$TC filter del dev $DEV_NAME ingress 
	cleanup

	echo "OK"
}



echo "cleanup"
cleanup
echo "begin run"
l2_to_ipip
