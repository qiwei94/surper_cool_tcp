#!/usr/bin/python
# -*- coding: UTF-8 -*-

import socket
import time
import sys

print('参数个数为:', len(sys.argv), '个参数。')
print('参数列表:', str(sys.argv))

cmd = ""
total = 100

if len(sys.argv)==3:
	cmd = str(sys.argv[1])
	print("cmd = ",cmd)
	total = int(str(sys.argv[2]))
	print("total = ",total)


IP=''
PORT=''


BPF_IP="10.0.6.10"
BPF_PORT="8005"


LVS_IP="10.0.4.1"
LVS_PORT="8010"


if cmd == "bpf":
	#IP=BPF_IP
	PORT=BPF_PORT
	print("use bpf "," PORT=",PORT)
elif cmd == "lvs":
	#IP=LVS_IP
	PORT=LVS_PORT
	print("use lvs "," PORT=",PORT)
else:
	print("not the format cmd , use BPF")
	print(" PORT=",PORT)




# 设置服务器默认端口号
#PORT = 8010
# 创建一个套接字socket对象，用于进行通讯
# socket.AF_INET 指明使用INET地址集，进行网间通讯
# socket.SOCK_DGRAM 指明使用数据协议，即使用传输层的udp协议
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
address = ("", int(PORT))
# 为服务器绑定一个固定的地址，ip和端口
server_socket.bind(address)
# 接收客户端传来的数据 recvfrom接收客户端的数据，默认是阻塞的，直到有客户端传来数据
# recvfrom 参数的意义，表示最大能接收多少数据，单位是字节
# recvfrom返回值说明
# receive_data表示接受到的传来的数据,是bytes类型, receive_data.decode()解码，将bytes类型转换为字符串类型
# client_address 表示传来数据的客户端的身份信息，客户端的ip和端口，元组
count=0
one_M=1000000 #1M
#total=5*one_M

now_ticks = 0

while count<total:
	receive_data, client = server_socket.recvfrom(1024)
	#print("来自客户端%s,发送的%s" % (client, receive_data.decode()))
	count=count+1
	if count==1:
		now_ticks = int(time.time())
		print("now begin time:",now_ticks)



end_ticks = int(time.time())

time = int(end_ticks - now_ticks)

pps = int(total/time)

print(total,":pckets,use:",time,"s  pps : ",pps)

#time.sleep(10)
#end_ticks = time.time()
#print("end",end_ticks)

# 不再接收数据的时候，将套接字socket关闭
server_socket.close()

