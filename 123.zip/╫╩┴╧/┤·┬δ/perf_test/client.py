#!/usr/bin/python
# -*- coding: UTF-8 -*-

import socket
import time
import sys
import argparse

print('参数个数为:', len(sys.argv), '个参数。')
print('参数列表:', str(sys.argv))

cmd = ""
total = 100

if len(sys.argv)==3:
	cmd = str(sys.argv[1])
	print("cmd = ",cmd)
	total = int(str(sys.argv[2]))
	print("total = ",total)


IP=''
PORT=''

BPF_IP="10.0.6.10"
BPF_PORT="8005"


LVS_IP="10.0.4.1"
LVS_PORT="8010"


if cmd == "bpf":
	IP=BPF_IP
	PORT=BPF_PORT
	print("use LVS,IP=",IP," PORT=",PORT)
elif cmd == "lvs":
	IP=LVS_IP
	PORT=LVS_PORT
	print("use bpf,IP=",IP," PORT=",PORT)
else:
	print("not the format cmd , use BPF")
	print(" IP=",IP," PORT=",PORT)


client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

count=0
one_M=1000000 #1M

msg = "123456789012345678901234567890123456789012345678901234567890"

while count < total:
#while True:
    #msg = input("请输入要发送的内容：")
    count=count+1   
    server_address = (IP, int(PORT))  
    client_socket.sendto(msg.encode(), server_address)
    #time.sleep(1)

