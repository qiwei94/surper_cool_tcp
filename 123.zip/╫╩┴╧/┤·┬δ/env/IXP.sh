#!/bin/bash -x
remote_control_ip='10.10.1.1' 
REMOTE_DATA_IP='10.10.1.1'

ip route del 10.0.5.0/24 via $remote_control_ip
ip route add 10.0.5.0/24 via $remote_control_ip  # the real IP


ip netns exec target2 ip -all tunnel delete IXT

ip netns exec target2 modprobe ipip
# 
# # in target2 set the tun0 ,and attach to veth3
# # the tun0 is connect to LB(10.0.1.0/)
ip netns exec target2 ip tunnel add IXT mode ipip remote $REMOTE_DATA_IP local 10.0.2.2
ip netns exec target2 ip link set IXT up
#ip netns exec target2 ip add add 10.0.5.20 peer 10.0.5.10 dev IXT
ip netns exec target2 ip addr add 10.0.6.10 dev IXT
##################################################################################################################need to change
ip netns exec target2 ip route add 10.0.5.0/24 dev IXT



ip netns exec target3 ip -all tunnel delete IXT

ip netns exec target3 modprobe ipip
# 
# # in target2 set the tun0 ,and attach to veth3
# # the tun0 is connect to LB(10.0.1.0/)
ip netns exec target3 ip tunnel add IXT mode ipip remote $REMOTE_DATA_IP local 10.0.2.3
ip netns exec target3 ip link set IXT up
#ip netns exec target2 ip add add 10.0.5.20 peer 10.0.5.10 dev IXT
ip netns exec target3 ip addr add 10.0.6.10 dev IXT
##################################################################################################################need to change
ip netns exec target3 ip route add 10.0.5.0/24 dev IXT