#!/bin/bash -x

remote_control_ip='10.10.1.1' 
REMOTE_DATA_IP='10.10.1.1'


ip -all netns delete

# clear the bridge
ip -all link delete br0

#clear the route
ip route del 10.0.4.0/24 via $remote_control_ip
ip route del 10.0.1.0/24 via $REMOTE_DATA_IPs
ip route add 10.0.6.10 via $remote_control_ip



echo "clear all........................................"

# add the client and the target2 \ target3
ip netns add client
ip netns add target2
ip netns add target3
echo "add all........................................"


# veth0 - veth1
# add veth to client, set it up and give it IP
ip link add veth0 type veth peer name veth1
ip link set veth1 netns client
ip netns exec client ip link set veth1 up
ip netns exec client ip addr add 10.0.3.2/24 dev veth1
echo "client set up finish........................................"

# veth2 - veth3
# add veth2 veth3 ,and add it to target2 , give IP to the veth
ip link add veth2 type veth peer name veth3
ip link set veth3 netns target2
ip netns exec target2 ip link set veth3 up
ip netns exec target2 ip addr add 10.0.2.2/24 dev veth3
echo "target2 set up finish........................................"

# veth4 - veth5
# the same as above
ip link add veth4 type veth peer name veth5
ip link set veth5 netns target3
ip netns exec target3 ip link set veth5 up
ip netns exec target3 ip addr add 10.0.2.3/24 dev veth5
echo "target3 set up finish........................................"


# veth0 connect to client give it ip address
ip link set veth0 up
ip addr add 10.0.3.1/24 dev veth0

# use bridge to connect to outside(in fact it is a gateway or switch)
ip link add name br0 type bridge
ip link set br0 up
ip addr add 10.0.2.1/24 dev br0


# add the veth2(target 2) to br0
ip link set veth2 master br0
ip link set veth2 up

# add the veth4(target 3) to br0
ip link set veth4 master br0
ip link set veth4 up

echo "interface set up finish........................................"




# give one route table to each of the onnection
# cleint veth0 -> veth1
ip netns exec client ip route add default via 10.0.3.1
# target2 veth2 -> br0
ip netns exec target2 ip route add default via 10.0.2.1
# target3 veth4 -> br0
ip netns exec target3 ip route add default via 10.0.2.1



echo "default IP set up finish........................................"


# use the master enviroment to forward the packet to outside with the eth of the master port
echo 1 > /proc/sys/net/ipv4/ip_forward
ip route add 10.10.1.0/24 via $REMOTE_DATA_IP  # the real IP
ip route add 10.0.4.0/24 via $remote_control_ip  # the real IP


echo "ip route :"
ip route show
echo "forward and toute table set up finish........................................"


# ##### configure the tunnel
modprobe ipip
# 
# # in target2 set the tun0 ,and attach to veth3
# # the tun0 is connect to LB(10.0.1.0/)
ip netns exec target2 ip tunnel add tun0 mode ipip local 10.0.2.2 dev veth3
ip netns exec target2 ip link set tun0 up
ip netns exec target2 ip addr add 10.0.4.1 dev tun0
echo "target2 tunnel set up finish........................................"

# 
# 
# # the same as above (target3 veth5) 
ip netns exec target3 ip tunnel add tun0 mode ipip local 10.0.2.3 dev veth5
ip netns exec target3 ip link set tun0 up
ip netns exec target3 ip addr add 10.0.4.1 dev tun0
echo "target3 tunnel set up finish........................................"




# 
# 
# # close the filter function
ip netns exec target2 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter'
ip netns exec target2 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/tun0/rp_filter'
echo "target2 filter set up finish........................................"


ip netns exec target3 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter'
ip netns exec target3 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/tun0/rp_filter'
echo "target3 filter set up finish........................................"

# 
# 
echo 2 > /proc/sys/net/ipv4/conf/br0/rp_filter

echo "br0 filter set up finish........................................"

ip netns exec target2 bash -c 'echo 1 > /proc/sys/net/ipv4/conf/tunl0/arp_ignore'
ip netns exec target2 bash -c 'echo 2 > /proc/sys/net/ipv4/conf/tunl0/arp_announce'
ip netns exec target2 bash -c 'echo 1 > /proc/sys/net/ipv4/conf/all/arp_ignore'
ip netns exec target2 bash -c 'echo 2 > /proc/sys/net/ipv4/conf/all/arp_announce'
ip netns exec target2 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/tunl0/rp_filter'
ip netns exec target2 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter'



ip netns exec target3 bash -c 'echo 1 > /proc/sys/net/ipv4/conf/tunl0/arp_ignore'
ip netns exec target3 bash -c 'echo 2 > /proc/sys/net/ipv4/conf/tunl0/arp_announce'
ip netns exec target3 bash -c 'echo 1 > /proc/sys/net/ipv4/conf/all/arp_ignore'
ip netns exec target3 bash -c 'echo 2 > /proc/sys/net/ipv4/conf/all/arp_announce'
ip netns exec target3 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/tunl0/rp_filter'
ip netns exec target3 bash -c 'echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter'



#ip netns exec client bash -c fish
#ip netns exec target2 bash -c fish
#ip netns exec target3 bash -c fish