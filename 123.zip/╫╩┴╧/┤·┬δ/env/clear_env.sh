#!/bin/bash -x

remote_control_ip='10.10.1.1' 
REMOTE_DATA_IP='10.10.1.1'


ip -all netns delete

# clear the bridge
ip -all link delete br0

#clear the route
ip route del 10.0.4.0/24 via $remote_control_ip
ip route del 10.0.1.0/24 via $REMOTE_DATA_IPs
ip route add 10.0.6.10 via $remote_control_ip



echo "clear all........................................"





